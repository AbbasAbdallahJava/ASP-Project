﻿namespace API_Final_Project.Repository
{
    public interface IProductRepository 
    {
    }
}
