﻿namespace API_Final_Project.Repository
{
    public class ProductRepository
    {
    }
}
