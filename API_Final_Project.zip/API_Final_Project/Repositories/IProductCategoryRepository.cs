﻿namespace API_Final_Project.Repositories
{
    public interface IProductCategoryRepository 
    {
    }
}
