﻿namespace API_Final_Project.Repositories
{
    public class ProductCategoryRepository
    {
    }
}
