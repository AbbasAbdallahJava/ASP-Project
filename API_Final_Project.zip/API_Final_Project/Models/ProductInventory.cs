﻿namespace API_Final_Project.Models
{
    public class ProductsInventory
    {
        public int ProductID { get; set; }
        public int LocationID { get; set; }
        public string shelf { get; set; }
        public int Bin { get; set; }
        public int Quantity { get; set; }
        public Guid rowguid { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
