﻿using API_Final_Project.Models;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace API_Final_Project.Controllers
{
    public class PhotoController:ControllerBase
    {
        private readonly IConfiguration _configuration;   // It needs access to application configuration setting                                                      // which is why it has a field _configuration of type IConfiguration.
        public PhotoController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        [HttpGet("GetProductThumbnailByID")]
        public async Task<IEnumerable<ProductPhoto>> GetProductThumbnailByID()
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");
            DataTable dataTable = new DataTable();
            using (SqlConnection Connection = new SqlConnection(connectionString))
            {
                Connection.Open();
                var Results = await Connection.QueryAsync<ProductPhoto>("GetProductThumbnailByID", commandType: CommandType.StoredProcedure);

                Connection.Close();
                Connection.Close();
                return (IEnumerable<ProductPhoto>)Results.ToList();
            }
        }
        [HttpGet("GetProductLargePhotoByID")]
        public async Task<IEnumerable<ProductPhoto>> GetProductLargePhotoByID()
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");
            DataTable dataTable = new DataTable();
            using (SqlConnection Connection = new SqlConnection(connectionString))
            {
                Connection.Open();
                var Results = await Connection.QueryAsync<ProductPhoto>("GetProductLargePhotoByID", commandType: CommandType.StoredProcedure);

                Connection.Close();
                Connection.Close();
                return (IEnumerable<ProductPhoto>)Results.ToList();
            }
        }
        [HttpGet("GetAllPhoto")]
        public async Task<IEnumerable<ProductPhoto>> GetAllPhoto()
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");
            DataTable dataTable = new DataTable();
            using (SqlConnection Connection = new SqlConnection(connectionString))
            {
                Connection.Open();
                var Results = await Connection.QueryAsync<ProductPhoto>("GetAllProductPhotos", commandType: CommandType.StoredProcedure);

                Connection.Close();
                Connection.Close();
                return (IEnumerable<ProductPhoto>)Results.ToList();
            }
        }
    }
}
