﻿using API_Final_Project.Models;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System;
using System.Data;

namespace API_Final_Project.Controllers
{
    public class CategoryController : ControllerBase
    {
        private readonly IConfiguration _configuration;   // It needs access to application configuration setting                                                      // which is why it has a field _configuration of type IConfiguration.
        public CategoryController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        [HttpPost("InsertCategory")]
        public async void InsertCategory(ProductsCategory category)

        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            using (SqlConnection Connection = new SqlConnection(connectionString))
            {
                Connection.Open();

                // Insert the category

                var categoryParams = new DynamicParameters();
                categoryParams.Add("@Name", category.Name);
                categoryParams.Add("@rowguid", category.rowguid);
                categoryParams.Add("@ModifiedDate", category.ModifiedDate);

                var Results = await Connection.QueryAsync<ProductsCategory>("InsertCategory1", categoryParams, commandType: CommandType.StoredProcedure);

                Connection.Close();

            }
        }
        [HttpPut("UpdateCategory/{id}")]
        public async void UpdateCategory(ProductsCategory category, int id, [FromBody] ProductsCategory updatedCategory)

        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            using (SqlConnection Connection = new SqlConnection(connectionString))
            {
                Connection.Open();
                var categoryParams = new DynamicParameters();
                categoryParams.Add("@Name", category.Name);
                categoryParams.Add("@rowguid", category.rowguid);
                categoryParams.Add("@ModifiedDate", category.ModifiedDate);

                var Results = await Connection.QueryAsync<ProductsCategory>("UpdateCategory1", categoryParams, commandType: CommandType.StoredProcedure);

                Connection.Close();
            }

        }
        [HttpDelete("DeleteCategory/{id}")]
        public async void DeleteCategory(ProductsCategory category, int id, [FromBody] ProductsCategory updatedCategory)

        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            using (SqlConnection Connection = new SqlConnection(connectionString))
            {
                Connection.Open();
                var categoryParams = new DynamicParameters();
                categoryParams.Add("@ProductCategoryID", id);

                await Connection.ExecuteAsync("DeleteCategory", categoryParams, commandType: CommandType.StoredProcedure);

                Connection.Close();
            }
        }
        [HttpGet("GetProductByCategory")]
        public async Task<IEnumerable<ProductsCategory>> GetProductByCategory()
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");
            DataTable dataTable = new DataTable();
            using (SqlConnection Connection = new SqlConnection(connectionString))
            {
                Connection.Open();
                var Results = await Connection.QueryAsync<Product>("GetProductByCategory", commandType: CommandType.StoredProcedure);

                Connection.Close();
                Connection.Close();
                return (IEnumerable<ProductsCategory>)Results.ToList();
            }
        }
    }
}



