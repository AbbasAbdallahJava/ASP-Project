﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using Dapper;
using API_Final_Project.Models;

namespace API_Final_Project.Controllers
{

    public class ProductController : ControllerBase 
    {
        private readonly IConfiguration _configuration;   // It needs access to application configuration setting                                                      // which is why it has a field _configuration of type IConfiguration.
        public ProductController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        [HttpPost("InsertProduct")]
        public async void InsertProduct(Product product)

        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            using (SqlConnection Connection = new SqlConnection(connectionString))
            {
                Connection.Open();
                Guid productGuid = Guid.NewGuid();
                var Params = new DynamicParameters();
                Params.Add("@Name", product.Name); // '@Name' parameter
                Params.Add("@ProductNumber", product.ProductNumber);
                Params.Add("@MakeFlag", product.MakeFlag);
                Params.Add("@FinishedGoodsFlag", product.FinishedGoodsFlag);
                Params.Add("@Color", product.Color);
                Params.Add("@SafetyStockLevel", product.SafetyStockLevel);
                Params.Add("@ReorderPoint", product.ReorderPoint);
                Params.Add("@StandardCost", product.StandardCost);
                Params.Add("@ListPrice", product.ListPrice);
                Params.Add("@Size", product.Size);
                Params.Add("@SizeUnitMeasureCode", product.SizeUnitMeasureCode);
                Params.Add("@WeightUnitMeasureCode", product.WeightUnitMeasureCode);
                Params.Add("@Weight", product.Weight);
                Params.Add("@DaysToManufacture", product.DaysToManufacture);
                Params.Add("@ProductLine", product.ProductLine);
                Params.Add("@Class", product.Class);
                Params.Add("@Style", product.Style);
                Params.Add("@ProductSubcategoryID", product.ProductSubcategoryID);
                Params.Add("@ProductModelID", product.ProductModelID);
                Params.Add("@SellStartDate", product.SellStartDate);
                Params.Add("@SellEndDate", product.SellEndDate);
                Params.Add("@DiscontinuedDate", product.DiscontinuedDate);
                Params.Add("@rowguid", productGuid);
                Params.Add("@ModifiedDate", product.ModifiedDate);

                var Results = await Connection.QueryAsync<Product>("InsertNewProduct5", Params, commandType: CommandType.StoredProcedure);

                Connection.Close();
            }
        }
        [HttpPut("UpdateProduct/{id}")]
        public async void UpdateProduct(Product product, int id, [FromBody] Product updatedProduct)

        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            using (SqlConnection Connection = new SqlConnection(connectionString))
            {
                Connection.Open();
                Guid productGuid = Guid.NewGuid();
                var Params = new DynamicParameters();
                Params.Add("@ProductID", id);
                Params.Add("@Name", product.Name); // '@Name' parameter
                Params.Add("@ProductNumber", product.ProductNumber);
                Params.Add("@MakeFlag", product.MakeFlag);
                Params.Add("@FinishedGoodsFlag", product.FinishedGoodsFlag);
                Params.Add("@Color", product.Color);
                Params.Add("@SafetyStockLevel", product.SafetyStockLevel);
                Params.Add("@ReorderPoint", product.ReorderPoint);
                Params.Add("@StandardCost", product.StandardCost);
                Params.Add("@ListPrice", product.ListPrice);
                Params.Add("@Size", product.Size);
                Params.Add("@SizeUnitMeasureCode", product.SizeUnitMeasureCode);
                Params.Add("@WeightUnitMeasureCode", product.WeightUnitMeasureCode);
                Params.Add("@Weight", product.Weight);
                Params.Add("@DaysToManufacture", product.DaysToManufacture);
                Params.Add("@ProductLine", product.ProductLine);
                Params.Add("@Class", product.Class);
                Params.Add("@Style", product.Style);
                Params.Add("@ProductSubcategoryID", product.ProductSubcategoryID);
                Params.Add("@ProductModelID", product.ProductModelID);
                Params.Add("@SellStartDate", product.SellStartDate);
                Params.Add("@SellEndDate", product.SellEndDate);
                Params.Add("@DiscontinuedDate", product.DiscontinuedDate);
                Params.Add("@rowguid", productGuid);
                Params.Add("@ModifiedDate", product.ModifiedDate);




                var Results = await Connection.QueryAsync<Product>("[UpdateProduct]", Params, commandType: CommandType.StoredProcedure);

                Connection.Close();
            }
        }
        [HttpDelete("DeleteProduct/{id}")]
        public async void DeleteProduct(int id)
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                var Params = new DynamicParameters();
                Params.Add("@ProductID", id);

                await connection.ExecuteAsync("DeleteProduct", Params, commandType: CommandType.StoredProcedure);

                connection.Close();
            }
        }
        [HttpGet("GetAllProduct")]
        public async Task<IEnumerable<Product>> GetAllProduct()
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");
            DataTable dataTable = new DataTable();
            using (SqlConnection Connection = new SqlConnection(connectionString))
            {
                Connection.Open();

                //for sending params
                //var Params = new DynamicParameters();
                //Params.Add("@Name", param1);
                //var Results = await Connection.QueryAsync<Product>("InsertNewProduct",params, commandType: CommandType.StoredProcedure);

                var Results = await Connection.QueryAsync<Product>("GetAllProducts", commandType: CommandType.StoredProcedure);

                Connection.Close();
                Connection.Close();
                return Results.ToList();
            }
        }

    }
}
