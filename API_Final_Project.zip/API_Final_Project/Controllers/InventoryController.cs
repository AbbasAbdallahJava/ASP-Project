﻿using API_Final_Project.Models;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace API_Final_Project.Controllers
{
    public class InventoryController : ControllerBase
    {
        private readonly IConfiguration _configuration;   // It needs access to application configuration setting                                                      // which is why it has a field _configuration of type IConfiguration.
        public InventoryController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        [HttpPost("InsertProductInventory")]
        public async void InsertProductInventory(ProductsInventory inventory)

        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            using (SqlConnection Connection = new SqlConnection(connectionString))
            {
                Connection.Open();
                Guid rowguid = Guid.NewGuid();
                var Params = new DynamicParameters();
                Params.Add("@LocationID", inventory.LocationID);
                Params.Add("@shelf", inventory.shelf);
                Params.Add("@Bin", inventory.Bin);
                Params.Add("@Quantity", inventory.Quantity);
                Params.Add("@rowguid", inventory.rowguid);
                Params.Add("@ModifiedDate", inventory.ModifiedDate);
                var Results = await Connection.QueryAsync<ProductsInventory>("InsertProductInventory", Params, commandType: CommandType.StoredProcedure);

                Connection.Close();

            }
        }
        [HttpPut("UpdateInventory/{id}")]
        public async void UpdateInventory(ProductsInventory inventory, int id, [FromBody] ProductsInventory updatedInventory)

        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            using (SqlConnection Connection = new SqlConnection(connectionString))
            {
                Connection.Open();
                Guid rowguid = Guid.NewGuid();
                var Params = new DynamicParameters();
                Params.Add("@LocationID", inventory.LocationID);
                Params.Add("@shelf", inventory.shelf);
                Params.Add("@Bin", inventory.Bin);
                Params.Add("@Quantity", inventory.Quantity);
                Params.Add("@rowguid", inventory.rowguid);
                Params.Add("@ModifiedDate", inventory.ModifiedDate);
                var Results = await Connection.QueryAsync<ProductsInventory>("UpdateProductInventory", Params, commandType: CommandType.StoredProcedure);

                Connection.Close();

            }
        }
        [HttpGet("GetProductsInShelf")]
        public async Task<IEnumerable<ProductsInventory>> GetProductsInShelf()
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");
            DataTable dataTable = new DataTable();
            using (SqlConnection Connection = new SqlConnection(connectionString))
            {
                Connection.Open();
                var Results = await Connection.QueryAsync<ProductsInventory>("GetProductsInShelf", commandType: CommandType.StoredProcedure);

                Connection.Close();
                Connection.Close();
                return (IEnumerable<ProductsInventory>)Results.ToList();
            }
        }
        [HttpGet("GetProductsByQuantity")]
        public async Task<IEnumerable<ProductsInventory>> GetProductsByQuantity()
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");
            DataTable dataTable = new DataTable();
            using (SqlConnection Connection = new SqlConnection(connectionString))
            {
                Connection.Open();
                var Results = await Connection.QueryAsync<ProductsInventory>("GetProductsByQuantity", commandType: CommandType.StoredProcedure);

                Connection.Close();
                Connection.Close();
                return (IEnumerable<ProductsInventory>)Results.ToList();
            }
        }
    }
}