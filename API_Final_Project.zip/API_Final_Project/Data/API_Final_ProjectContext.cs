﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using API_Final_Project.Models;

namespace API_Final_Project.Data
{
    public class API_Final_ProjectContext : DbContext
    {
        public API_Final_ProjectContext (DbContextOptions<API_Final_ProjectContext> options)
            : base(options)
        {
        }

        public DbSet<API_Final_Project.Models.ProductsCategory> Product { get; set; } = default!;
    }
}
